/* Locations transcribed from the official UNISEC Moscow-region map. */
(() => {
  const root = document.querySelector('#locations-v14');
  if (!root) return;
  const points = [
    {title:'Москва — ТРЦ «Бутово Молл»',city:'Москва',address:'г. Москва, пос. Воскресенское, Чечёрский проезд, д. 51, ТРЦ «Бутово Молл»',hours:'10:00–22:00, пн–вс',phones:['8 (925) 510-57-54','8 (499) 390-99-24'],lat:55.524292483215,lon:37.516439124329},
    {title:'Балашиха — «Билла»',city:'Балашиха',address:'Московская область, г. Балашиха, Балашихинское шоссе, дом 10, магазин «Билла»',hours:'9:00–20:00',phones:['8 (903) 011-87-59'],lat:55.822515521324,lon:37.933045356483},
    {title:'Железнодорожный — «Рождественская, 4»',city:'Железнодорожный',address:'Московская область, г. Балашиха, микрорайон Железнодорожный, ул. Рождественская, д. 4',hours:'Вт–пт 10:00–19:00; сб, вс 10:00–18:00; понедельник — выходной',phones:['8 (968) 770-72-80'],lat:55.743914701291,lon:38.003512136246},
    {title:'Монино',city:'Монино',address:'Монино, Железнодорожная, 31А',hours:'9:00–22:00',phones:['+7 903 011-85-19'],lat:55.843734093015,lon:38.199479434594},
    {title:'Ногинск — «Богородский»',city:'Ногинск',address:'Московская область, г. Ногинск, ул. 3-Интернационала, д. 62, ТК «Богородские ряды»',hours:'10:00–21:00, пн–вс',phones:['8 (967) 146-84-80'],lat:55.855821892318,lon:38.440420074066},
    {title:'Ногинск — «Фабрика»',city:'Ногинск',address:'Московская область, г. Ногинск, 2-й Истомкинский проезд, д. 2А, Фабрика',hours:'9:00–20:00',phones:['8 (496) 519-57-70','8 (963) 679-26-96'],lat:55.839590488815,lon:38.404276974869},
    {title:'Павловский Посад — «Апрель»',city:'Павловский Посад',address:'Московская область, г. Павловский Посад, ул. Кирова, д. 5, ТЦ «Апрель»',hours:'9:00–20:00',phones:['8 (969) 169-14-41'],lat:55.778982940078,lon:38.65009829266},
    {title:'Старая Купавна',city:'Старая Купавна',address:'Московская область, г. Старая Купавна, ул. Большая Московская, д. 3',hours:'9:00–20:00',phones:['8 (969) 169-07-96'],lat:55.807799560584,lon:38.164787334438},
    {title:'Электросталь — «Перекрёсток»',city:'Электросталь',address:'Московская область, г. Электросталь, ул. Мира, д. 22, слева от супермаркета «Перекрёсток»',hours:'Будни 10:00–20:00 (обед 14:00–14:30); сб 10:00–19:00, вс 10:00–18:00',phones:['8 (906) 094-13-89'],lat:55.774776731123,lon:38.445799263055},
    {title:'Электроугли',city:'Электроугли',address:'Московская область, г. Электроугли, ул. Школьная, д. 35',hours:'9:00–20:00',phones:['8 (964) 509-68-67'],lat:55.717449507491,lon:38.220301850857}
  ];
  root.classList.add('locations-v14');
  root.innerHTML = `<div class="locations-v14__head"><div><p class="eyebrow">/ ПУНКТЫ ПРИЁМА</p><h2>UNISEC <em>рядом.</em></h2></div><p>Выберите удобный пункт приёма и выдачи в Москве и Подмосковье</p></div>
    <div class="locations-v14__benefits" aria-label="Преимущества"><span>Рядом с домом</span><span>Удобный график</span><span>Приём и выдача в одном месте</span></div>
    <div class="locations-v14__layout"><div class="locations-v14__directory"><div class="locations-v14__toolbar"><h3>Пункты приёма</h3><label for="locations-city-v14">Город</label><select id="locations-city-v14"><option value="">Все города</option></select></div><div class="locations-v14__nearby"><button type="button" class="locations-v14__nearby-button">Найти ближайшие</button><p class="locations-v14__nearby-status" role="status" aria-live="polite"></p></div><p class="locations-v14__notice">Перед визитом уточняйте график работы пункта.</p><div class="locations-v14__list" aria-label="Адреса пунктов приёма"></div><a class="locations-v14__source" href="https://unisec-msk.ru/punkts" target="_blank" rel="noopener">Все адреса на официальном сайте ↗</a></div>
    <div class="locations-v14__map-wrap"><iframe class="locations-v14__map" title="Карта пунктов UNISEC" loading="lazy" allowfullscreen referrerpolicy="no-referrer-when-downgrade"></iframe><a class="locations-v14__map-link" href="https://yandex.ru/maps/?text=UNISEC" target="_blank" rel="noopener">Открыть карту в Яндексе ↗</a></div></div>`;
  const list = root.querySelector('.locations-v14__list');
  const filter = root.querySelector('select');
  const frame = root.querySelector('iframe');
  const mapLink = root.querySelector('.locations-v14__map-link');
  const nearbyButton = root.querySelector('.locations-v14__nearby-button');
  const nearbyStatus = root.querySelector('.locations-v14__nearby-status');
  let userPosition = null;
  const distanceKm = (point, position) => {
    const radians = degrees => degrees * Math.PI / 180;
    const deltaLat = radians(point.lat - position.latitude);
    const deltaLon = radians(point.lon - position.longitude);
    const a = Math.sin(deltaLat / 2) ** 2 + Math.cos(radians(position.latitude)) * Math.cos(radians(point.lat)) * Math.sin(deltaLon / 2) ** 2;
    return 6371 * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(Math.max(0, 1 - a)));
  };
  const pins=points.map(point=>`${point.lon},${point.lat},pm2rdm`).join('~');
  const defaultMap = `https://yandex.ru/map-widget/v1/?ll=38.0%2C55.78&z=9&l=map&mode=search&text=UNISEC&pt=${encodeURIComponent(pins)}`;
  frame.src = defaultMap;
  [...new Set(points.map(point => point.city))].forEach(city => {
    const option = document.createElement('option'); option.value = city; option.textContent = city; filter.append(option);
  });
  const cardFor = point => {
    const card = document.createElement('article'); card.className='locations-v14__card';
    const heading = document.createElement('h4'); heading.textContent=point.title;
    const address = document.createElement('p'); address.textContent=point.address;
    const hours = document.createElement('p'); hours.className='locations-v14__hours'; hours.textContent=`Часы работы: ${point.hours}`;
    const distance = document.createElement('p'); distance.className='locations-v14__distance';
    if (userPosition) distance.textContent = `По прямой: ${distanceKm(point, userPosition).toLocaleString('ru-RU', {maximumFractionDigits: 1})} км`;
    const phones = document.createElement('p'); phones.className='locations-v14__phones';
    point.phones.forEach((phone,index) => {
      if(index) phones.append(' · ');
      const link=document.createElement('a');link.href=`tel:${phone.replace(/[^+\d]/g,'')}`;link.textContent=phone;phones.append(link);
    });
    const actions=document.createElement('div');actions.className='locations-v14__actions';
    const show=document.createElement('button');show.type='button';show.textContent='На карте';show.setAttribute('aria-label',`Показать на карте: ${point.title}`);
    const route=document.createElement('a');route.target='_blank';route.rel='noopener';route.href=`https://yandex.ru/maps/?rtext=~${point.lat}%2C${point.lon}&rtt=auto`;route.textContent='Маршрут ↗';route.setAttribute('aria-label',`Построить маршрут: ${point.title}`);
    show.addEventListener('click',() => {
      const search = encodeURIComponent(`UNISEC, ${point.address}`);
      frame.src=`https://yandex.ru/map-widget/v1/?ll=${point.lon}%2C${point.lat}&z=16&l=map&mode=search&text=${search}&pt=${encodeURIComponent(`${point.lon},${point.lat},pm2rdm`)}`;
      frame.title=`Карта: ${point.title}`;
      mapLink.href=`https://yandex.ru/maps/?ll=${point.lon}%2C${point.lat}&z=16&text=${search}`;
      list.querySelectorAll('.locations-v14__card').forEach(item=>item.classList.remove('is-selected'));
      card.classList.add('is-selected');
      if (matchMedia('(max-width: 900px)').matches) frame.scrollIntoView({behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'auto':'smooth',block:'center'});
    });
    actions.append(show,route);card.append(heading,address,hours,phones);if(userPosition) card.append(distance);card.append(actions);return card;
  };
  const render = () => {
    const visible = points.filter(point=>!filter.value || point.city===filter.value);
    if (userPosition) visible.sort((a, b) => distanceKm(a, userPosition) - distanceKm(b, userPosition));
    list.replaceChildren(...visible.map(cardFor));
  };
  nearbyButton.addEventListener('click', () => {
    if (!navigator.geolocation) {
      nearbyStatus.textContent = 'Геолокация недоступна. Выберите город из списка.';
      return;
    }
    nearbyButton.disabled = true;
    nearbyStatus.textContent = 'Определяем ваше местоположение…';
    navigator.geolocation.getCurrentPosition(position => {
      userPosition = {latitude: position.coords.latitude, longitude: position.coords.longitude};
      filter.value = '';
      nearbyStatus.textContent = 'Пункты отсортированы по расстоянию по прямой.';
      nearbyButton.disabled = false;
      render();
    }, () => {
      nearbyButton.disabled = false;
      nearbyStatus.textContent = 'Не удалось определить местоположение. Выберите город из списка.';
    }, {enableHighAccuracy: false, timeout: 10000, maximumAge: 300000});
  });
  filter.addEventListener('change',render);render();
})();
